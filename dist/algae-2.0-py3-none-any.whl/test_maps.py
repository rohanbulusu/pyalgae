
from maps import *

import math
from pytest import raises

from algaeset import C, R, Z, N


class TestMapping:

	def test_accepts_lambdas(self):
		assert Mapping(lambda x: x**2, [R], [R])

	def test_accepts_functions(self):
		def f(x):
			return x**2
		assert Mapping(f, [R], [R])

	def test_checks_domains(self):
		m = Mapping(lambda a, b, c: a, [R, Z, N], [R])
		assert m(1, 2, 3) == 1
		assert m(math.pi, -14, 12) == math.pi
		with raises(DomainError):
			m(12, -14, 12)
		with raises(DomainError):
			m(math.pi, math.pi, 12)
		with raises(DomainError):
			m(math.pi, -14, -12)
