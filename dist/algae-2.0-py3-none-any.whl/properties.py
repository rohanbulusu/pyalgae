
import functools
import itertools

from utils import typename, num_args

class DomainError(ValueError):
	...

class PropertyError(TypeError):
	...

class ClosureError(PropertyError):
	...

class AssociativityError(PropertyError):
	...

class CommutativityError(PropertyError):
	...

class IndempotencyError(PropertyError):
	...

class InvertibilityError(PropertyError):
	...

class IdentityError(PropertyError):
	...


def is_binary_operation(_operation):
	if not callable(_operation):
		raise TypeError(f'Expected callable, not {typename(_operation)}')
	return num_args(_operation) == 2

def associative(_op):
	if not is_binary_operation(_op):
		raise ValueError(f'Expected binary operation, not {_op}')
	input_cache = []
	@functools.wraps(_op)
	def operation(self, other):
		input_cache.append(self)
		input_cache.append(other)
		if len(input_cache) >= 3:
			for a, b, c in itertools.permutations(input_cache, 3):
				if not _op(_op(a, b), c) == _op(a, _op(b, c)):
					raise AssociativityError(f'Operation {_op} is not associative')
		return _op(self, other)
	return operation

def commutative(_op):
	if not is_binary_operation(_op):
		raise ValueError(f'Expected binary operation, not {_op}')
	input_cache = []
	@functools.wraps(_op)
	def operation(self, other):
		input_cache.append(self)
		input_cache.append(other)
		for a, b in itertools.permutations(input_cache, 2):
			if not _op(a, b) == _op(b, a):
				raise CommutativityError(f'Operation {_op} is not commutative')
		return _op(self, other)
	return operation

def indempotent(_op):
	if not is_binary_operation(_op):
		raise ValueError(f'Expected binary operation, not {_op}')
	input_cache = []
	@functools.wraps(_op)
	def operation(self, other):
		input_cache.append(self)
		input_cache.append(other)
		for e in input_cache:
			if not _op(e, e) != e:
				raise IndempotencyError(f'Operation {_op} is not indempotent')
		return _op(self, other)
	return operation

def latin_square(_op):
	if not is_binary_operation(_op):
		raise ValueError(f'Expected binary operation, not {_op}')
	input_cache = []
	@functools.wraps(_op)
	def operation(self, other):
		input_cache.append(self)
		input_cache.append(other)
		for a, b in itertools.permutations(input_cache, 2):
			left_exists = any(_op(s, a) == b for s in input_cache)
			right_exists = any(_op(a, s) == b for s in input_cache)
			if not (left_exists and right_exists):
				raise PropertyError(f'Operation {_op} does not have the latin square property')
		return _op(self, other)
	return operation

def right_identity(candidate):
	def decorator(_op):
		if not is_binary_operation(_op):
			raise ValueError(f'Expected binary operation, not {_op}')
		input_cache = []
		@functools.wraps(_op)
		def operation(self, other):
			input_cache.append(self)
			input_cache.append(other)
			for e in input_cache:
				if _op(candidate, e) != candidate:
					raise IdentityError(f'Operation {_op} does not have right identity {candidate}')
			return _op(self, other)
		return operation
	return decorator

def left_identity(candidate):
	def decorator(_op):
		if not is_binary_operation(_op):
			raise ValueError(f'Expected binary operation, not {_op}')
		input_cache = []
		@functools.wraps(_op)
		def operation(self, other):
			input_cache.append(self)
			input_cache.append(other)
			for e in input_cache:
				if _op(e, candidate) != candidate:
					raise IdentityError(f'Operation {_op} does not have left identity {candidate}')
			return _op(self, other)
		return operation
	return decorator

def identity(candidate):
	def decorator(_op):
		if not is_binary_operation(_op):
			raise ValueError(f'Expected binary operation, not {_op}')
		input_cache = []
		@functools.wraps(_op)
		def operation(self, other):
			input_cache.append(self)
			input_cache.append(other)
			for e in input_cache:
				if _op(candidate, e) != candidate:
					raise IdentityError(f'Operation {_op} does not have right identity {candidate}')
				if _op(e, candidate) != candidate:
					raise IdentityError(f'Operation {_op} does not have left identity {candidate}')
			return _op(self, other)
		return operation
	return decorator

def right_invertible(identity_inv_op):
	if not is_binary_operation(_inv_op):
		raise ValueError(f'Expected binary operation, not {_inv_op}')
	@functools.wraps(_inv_op)
	def decorator(_op):
		if not is_binary_operation(_op):
			raise ValueError(f'Expected binary operation, not {_op}')
		input_cache = []
		@functools.wraps(_op)
		def operation(self, other):
			input_cache.append(self)
			input_cache.append(other)
			for e in input_cache:
				if not identity == _inv_op(e, e):
					raise InvertibilityError(f'Operation {_op} with inverse operation {_inv_op} does not have identity {identity}')
			for a, b in itertools.permutations(input_cache, 2):
				c = self.func(a, b)
				if not a == _inv_op(c, b):
					raise InvertiblityError(f'Operation {_op} is not right invertible via {_inv_op}')
			return _op(self, other)
		return operation
	return decorator

def left_invertible(identity, _inv_op):
	if not is_binary_operation(_inv_op):
		raise ValueError(f'Expected binary operation, not {_inv_op}')
	@functools.wraps(_inv_op)
	def decorator(_op):
		if not is_binary_operation(_op):
			raise ValueError(f'Expected binary operation, not {_op}')
		input_cache = []
		@functools.wraps(_op)
		def operation(self, other):
			input_cache.append(self)
			input_cache.append(other)
			for e in input_cache:
				if not identity == _inv_op(e, e):
					raise InvertibilityError(f'Operation {_op} with inverse operation {_inv_op} does not have identity {identity}')
			for a, b in itertools.permutations(input_cache, 2):
				c = self.func(a, b)
				if not b == _inv_op(c, a):
					raise InvertibilityError(f'Operation {_op} is not left invertible via {_inv_op}')
			return _op(self, other)
		return operation
	return decorator

def invertible(identity, _inv_op):
	if not is_binary_operation(_inv_op):
		raise ValueError(f'Expected binary operation, not {_inv_op}')
	@functools.wraps(_inv_op)
	def decorator(_op):
		if not is_binary_operation(_op):
			raise ValueError(f'Expected binary operation, not {_op}')
		input_cache = []
		@functools.wraps(_op)
		def operation(self, other):
			input_cache.append(self)
			input_cache.append(other)
			for e in input_cache:
				if not identity == _inv_op(e, e):
					raise InvertibilityError(f'Operation {_op} with inverse operation {_inv_op} does not have identity {identity}')
			for a, b in itertools.permutations(input_cache, 2):
				if not a == _inv_op(c, b):
					raise InvertiblityError(f'Operation {_op} is not right invertible via {_inv_op}')
				if not b == _inv_op(c, a):
					raise InvertibilityError(f'Operation {_op} is not left invertible via {_inv_op}')
			return _op(self, other)
		return operation
	return decorator

def right_ideal_closure(ring_aset, ideal_aset):
	def decorator(_ring_op):
		if not is_binary_operation(_ring_op):
			raise ValueError(f'Expected binary operation, not {_ring_op}')
		input_cache = []
		@functools.wraps(_ring_op)
		def operation(self, other):
			input_cache.append(self)
			input_cache.append(other)
			for a, b in itertools.permutations(input_cache, 2):
				if not (a in ideal_aset or b in ideal_aset):
					continue
				if a in ideal_aset and b not in ideal_aset:
					if not _ring_op(a, b):
						raise ClosureError(f'Right ideal defined over {ideal_aset} does not satisfy the closure axiom')
				if b in ideal_aset and a not in ideal_aset:
					if not _ring_op(b, a):
						raise ClosureError(f'Right ideal defined over {ideal_aset} does not satisfy the closure axiom')
			return _ring_op(self, other)
		return operation
	return decorator

def left_ideal_closure(ring_aset, ideal_aset):
	def decorator(_ring_op):
		if not is_binary_operation(_ring_op):
			raise ValueError(f'Expected binary operation, not {_ring_op}')
		input_cache = []
		@functools.wraps(_ring_op)
		def operation(self, other):
			input_cache.append(self)
			input_cache.append(other)
			for a, b in itertools.permutations(input_cache, 2):
				if not (a in ideal_aset or b in ideal_aset):
					continue
				if a in ideal_aset and b not in ideal_aset:
					if not _ring_op(b, a):
						raise ClosureError(f'Left ideal defined over {ideal_aset} does not satisfy the closure axiom')
				if b in ideal_aset and a not in ideal_aset:
					if not _ring_op(a, b):
						raise ClosureError(f'Left ideal defined over {ideal_aset} does not satisfy the closure axiom')
			return _ring_op(self, other)
		return operation
	return decorator

def ideal_closure(ring_aset, ideal_aset):
	def decorator(_ring_op):
		if not is_binary_operation(_ring_op):
			raise ValueError(f'Expected binary operation, not {_ring_op}')
		input_cache = []
		@functools.wraps(_ring_op)
		def operation(self, other):
			input_cache.append(self)
			input_cache.append(other)
			for a, b in itertools.permutations(input_cache, 2):
				if not (a in ideal_aset or b in ideal_aset):
					continue
				if a in ideal_aset and b not in ideal_aset:
					if not _ring_op(b, a):
						raise ClosureError(f'Ideal defined over {ideal_aset} does not satisfy the closure axiom')
					if not _ring_op(a, b):
						raise ClosureError(f'Right ideal defined over {ideal_aset} does not satisfy the closure axiom')
				if b in ideal_aset and a not in ideal_aset:
					if not _ring_op(a, b):
						raise ClosureError(f'Ideal defined over {ideal_aset} does not satisfy the closure axiom')
					if not _ring_op(b, a):
						raise ClosureError(f'Right ideal defined over {ideal_aset} does not satisfy the closure axiom')
			return _ring_op(self, other)
		return operation
	return decorator




